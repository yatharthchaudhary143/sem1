// WAP to swap two numbers using call by value

#include <stdio.h>

void swap(int a, int b){
    int temp;
    temp=a;
    a=b;
    b=temp;
    printf("Inside swap function:\n");
    printf("x = %d, y = %d\n", a, b);
}

int main(){
    int x=10, 
    y=20;

    printf("Before swap (in main):\n");
    printf("x = %d, y = %d\n", x, y);

    swap(x, y);
    printf("\n(Yatharth Chaudhary)");

    return 0;
}