// 37. WAP to remove all the occurrences of a character c from the string s. 
#include <stdio.h> 
 
int main() { 
    char str[100], result[100]; 
    char ch; 
    int i, j = 0; 
 
    printf("Enter a string: "); 
    gets(str); 
 
    printf("Enter character to remove: "); 
    scanf("%c", &ch); 
 
    for (i = 0; str[i] != '\0'; i++) { 
        if (str[i] != ch) { 
            result[j++] = str[i]; 
        } 
    } 
    result[j] = '\0'; 
 
    printf("Resulting string: %s\n", result); 
 
    return 0; 
} 