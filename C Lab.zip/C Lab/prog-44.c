// 44. Write a program to print, delete and copy contents of one file to another file.  

#include <stdio.h>

int main() {
    int choice;
    char file1[100], file2[100];
    char ch;
    FILE *fp1, *fp2;

    while (1) {
        printf("\n--- FILE OPERATIONS MENU ---\n");
        printf("1. Print file contents\n");
        printf("2. Copy file to another file\n");
        printf("3. Delete a file\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {

        case 1:   // Print file
            printf("Enter file name to print: ");
            scanf("%s", file1);

            fp1 = fopen(file1, "r");
            if (fp1 == NULL) {
                printf("Unable to open file!\n");
                break;
            }

            printf("\n--- File Contents ---\n");
            while ((ch = fgetc(fp1)) != EOF) {
                putchar(ch);
            }
            fclose(fp1);
            break;


        case 2:   // Copy file
            printf("Enter source file name: ");
            scanf("%s", file1);

            printf("Enter destination file name: ");
            scanf("%s", file2);

            fp1 = fopen(file1, "r");
            fp2 = fopen(file2, "w");

            if (fp1 == NULL || fp2 == NULL) {
                printf("Unable to open source or destination file!\n");
                break;
            }

            while ((ch = fgetc(fp1)) != EOF) {
                fputc(ch, fp2);
            }

            fclose(fp1);
            fclose(fp2);

            printf("File copied successfully!\n");
            break;


        case 3:   // Delete file
            printf("Enter file name to delete: ");
            scanf("%s", file1);

            if (remove(file1) == 0)
                printf("File deleted successfully!\n");
            else
                printf("Unable to delete file!\n");
            break;


        case 4:
            return 0;

        default:
            printf("Invalid choice!\n");
        }
    }

    return 0;
}
