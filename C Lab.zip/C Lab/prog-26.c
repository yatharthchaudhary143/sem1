// WAP to determine whether two arrays a and b have an elemnet in common

#include <stdio.h>

void printArray(int arr[], int size){
    for (int i=0; i<size; i++)
        printf("%d ", arr[i]);
}

int main() {
    int a[5]={4, 5, 2, 7, 8};
    int b[5]={9, 6, 3, 2, 1};

    int sizeA=sizeof(a)/sizeof(a[0]);
    int sizeB=sizeof(b)/sizeof(b[0]);

    printf("\nArray 1: ");
    printArray(a, sizeA);
    printf("\nArray 2: ");
    printArray(b, sizeB);

    for (int i=0; i<sizeA; i++) {
        for (int j=0; j<sizeB; j++) {
            if (a[i]==b[j]) {
                printf("\nArrays have an element in common: %d", a[i]);
                printf("\n(Yatharth Chaudhary)");
                return 0;  
            }
        }
    }

    printf("\nArrays do NOT have any elements in common");
    printf("\n(Yatharth Chaudhary)");

    return 0;
}
