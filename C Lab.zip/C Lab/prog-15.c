// Wap to find the factorial of the given number

#include <stdio.h>

int fact(int n){
    if (n<1)
        return 1;
    return n*fact(n-1);
}

int main (){

    int n;
    printf("Enter any Number: ");
    scanf("%d",&n);
    int res=fact(n);
    printf("Factorial of %d is %d\n", n, res);
    printf("\n(Yatharth Chaudhary)\n");

    return 0;
}