// WAP to create a structure named company which has name, adress, phone no. of employeesas member variables.
// Read the name of the company ,its adress, phone no. of employees. Finally display these members's values.


#include <stdio.h>

struct company {
    char name[100];
    char address[200];
    long long phone_no;
};

int main() {
    int n, i;
    struct company c[100];  

    printf("Enter number of Employees: ");
    scanf("%d", &n);
    getchar();

    for (i=0; i<n; i++) {
        printf("\nEnter details of Employee %d:\n", i+1);

        printf("Enter employee Name: ");
        fgets(c[i].name, sizeof(c[i].name), stdin);

        printf("Enter employee Address: ");
        fgets(c[i].address, sizeof(c[i].address), stdin);

        printf("Enter employee phone number: ");
        scanf("%lld", &c[i].phone_no);
        getchar();
    }

    printf("\n--- Employee Details ---\n");
    for (i=0; i<n; i++) {
        printf("\nEmployee %d:\n", i + 1);
        printf("Name: %s", c[i].name);
        printf("Address: %s", c[i].address);
        printf("Phone No.: %lld\n", c[i].phone_no);
    }

    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}