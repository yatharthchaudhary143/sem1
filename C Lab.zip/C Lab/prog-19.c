// WAP to print the following pattern.

#include <stdio.h>

int main() {
    printf("\n");
    int rows = 5;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= rows - i; j++) {
            printf(" ");
        }
        for (int k = 1; k <= 2 * i - 1; k++) {
            printf("*");
        }
        printf("\n");
    }
    printf("(Yatharth Chaudhary)\n");
    return 0;
}
