// 29. Write a program to print the element for given indexes in a 2-D array.

#include <stdio.h>

int main() {
    int rows, cols;
    int arr[50][50];
    int r, c;

    printf("Enter number of rows: ");
    scanf("%d", &rows);

    printf("Enter number of columns: ");
    scanf("%d", &cols);

    printf("\nEnter the elements of the %d x %d array:\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &arr[i][j]);
        }
    }

    printf("\nEnter row index: ");
    scanf("%d", &r);

    printf("Enter column index: ");
    scanf("%d", &c);

    // Check valid index
    if (r < 0 || r >= rows || c < 0 || c >= cols) {
        printf("Invalid index!\n");
    } else {
        printf("\nElement at arr[%d][%d] = %d\n", r, c, arr[r][c]);
    }

    return 0;
}
