// WAP to check whether a given number is even or odd using an if-else statement

#include <stdio.h>

int main(){

    int n;
    printf("Enter any Number: ");
    scanf("%d", &n);

    if (n%2==0){
        printf("%d is Even Number", n);
    }
    else {
        printf("%d is Odd number", n);
    }
    printf("\n(Yatharth Chaudhary)\n");

    return 0;
}