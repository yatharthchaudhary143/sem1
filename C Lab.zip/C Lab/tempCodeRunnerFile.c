

int main(){

    int arr[]={5,9,2,6,3};
    int *ptr[5];

    for (int i=0; i<5; i++){
        ptr[i]=&arr[i];
    }

    int *(*p)[5]=&ptr;

    printf("Array elements using pointer to an array of pointers:\n");
    for(int i=0; i<5; i++) {
        printf("%d ", *(*p)[i]);
    }

    printf("\n(Yatharth Chaudhary)");
    return 0;
}
