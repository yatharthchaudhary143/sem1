// 46. Write a program to get the largest element of an array using recursion.

#include <stdio.h>

int findMax(int arr[], int index, int n) {

    if (index == n - 1)
        return arr[index];

    int maxInRest = findMax(arr, index + 1, n);

    if (arr[index] > maxInRest)
        return arr[index];
    else
        return maxInRest;
}

int main() {
    int n;

    printf("Enter size of array: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d elements:\n", n);

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int max = findMax(arr, 0, n);

    printf("Largest element = %d\n", max);
    
    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}
