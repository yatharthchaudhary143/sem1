// 31. write a program to multiply 3x3 matrix. 
#include <stdio.h> 
int main() { 
int a[3][3], b[3][3], result[3][3] = {0}; 
// Input matrix A 
printf("Enter elements of 1st matrix (3x3):\n"); 
for (int i = 0; i < 3; i++) 
for (int j = 0; j < 3; j++) 
scanf("%d", &a[i][j]); 
// Input matrix B 
printf("Enter elements of 2nd matrix (3x3):\n"); 
for (int i = 0; i < 3; i++) 
for (int j = 0; j < 3; j++) 
scanf("%d", &b[i][j]); 
// Matrix multiplication 
for (int i = 0; i < 3; i++) 
for (int j = 0; j < 3; j++) 
for (int k = 0; k < 3; k++) 
result[i][j] += a[i][k] * b[k][j]; 
// Output result 
printf("Product of the matrices:\n"); 
for (int i = 0; i < 3; i++) { 
for (int j = 0; j < 3; j++) 
printf("%d ", result[i][j]); 
printf("\n"); 
} 
return 0; 
} 