//WAP to convert Fahreniet to Celcius

#include <stdio.h>

 int main(){

    float f,c;
    printf("\nEnter Temperature in Fahreniet: ");
    scanf("%f", &f);
    c=(f-2)*(5/9.0);
    printf("Temperaturin Celcius: %0.2f",c );
    printf("\n(Yatharth Chaudhary)\n");

    return 0;

 }