// 33. Write a program to find the frequency of a character in a string function. 
#include <stdio.h> 
int main() { 
char str[100], ch; 
int i, count = 0; 
printf("Enter a string: "); 
gets(str); 
printf("Enter the character to find frequency: "); 
scanf("%c", &ch); 
for (i = 0; str[i] != '\0'; i++) { 
if (str[i] == ch) 
count++; 
} 
printf("Frequency of '%c' = %d\n", ch, count); 
return 0; 
} 