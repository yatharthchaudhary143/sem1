// WAP to count the number of digits in an integer

#include <stdio.h>

int main(){

    int n;
    printf("\nEnter any integer: ");
    scanf("%d",&n);

    int count=0;

    while (n>=1){
        count++;
        n/=10;
    }

    printf("Number of digits are: %d",count);
    printf("\n(Yatharth Chaudhary)\n");

    return 0;
}