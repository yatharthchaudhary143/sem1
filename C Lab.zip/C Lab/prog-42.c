// Write a program to list all files and sub-directories in a directory.

#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
int main()
{
    struct dirent *entry;
    DIR *dp = opendir("."); // Open the current directory
    
    if (dp == NULL)
    {
        perror("opendir"); // Print the error message
        return 1;
    }
    
    printf("Listing files and directories:\n");
    
    while ((entry = readdir(dp)) != NULL)
    {
        printf("%s\n", entry->d_name); 
    }
    closedir(dp); // Close the directory stream

    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}
