// WAP to check whether a given number is palindrome or not

#include <stdio.h>

int main(){

    int n;
    printf("\nEnter any number: ");
    scanf("%d",&n);

    int rev=0;
    int org=n;
    int last;

    while (n>0){
        last=n%10;
        n/=10;
        rev=(rev*10)+last;
    }

    if (rev==org){
        printf("%d is a Palindrome",org);
    }
    else {
        printf("%d is not a Palindrome",org);
    }

    printf("\n(Yatharth Chaudhary)");
    return 0;
}