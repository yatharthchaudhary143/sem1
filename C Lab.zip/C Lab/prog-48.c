// 48. Write a program to calculate the power of a number using recursions.

#include <stdio.h>

int power(int base, int exp) {
    if (exp == 0)
        return 1;

    return base * power(base, exp - 1);
}

int main() {
    int base, exponent;

    printf("Enter base: ");
    scanf("%d", &base);

    printf("Enter exponent: ");
    scanf("%d", &exponent);

    int result = power(base, exponent);

    printf("%d^%d = %d\n", base, exponent, result);

    printf("\nYatharth Chaudhary\n");
    return 0;
}
