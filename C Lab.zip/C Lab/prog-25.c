/* WAP to print the values of given expressions:
(consider a[] of 5 elements, 
*p[] is an array of 5 pointers, 
**pp is a double pointer (**pp=p), 
and before accessing the values of these expressions increment the double-pointer)
 a) pp-p
 b)*pp-a
 c) **pp
 d) ++*pp
 e) ++**pp  */

#include <stdio.h>

int main(){

    int a[5]={10,20,30,40,50};
    int *p[5];

    for (int i=0;i<5;i++){
        p[i]=&a[i];
    }

    int **pp=p; 
 
    ++pp;
    printf("a) pp-p = %ld\n", pp-p);          
    printf("b) *pp-a = %ld\n", *pp-a);        
    printf("c) **pp = %d\n", **pp);                
    printf("d) ++*pp = %p (points to value %d)\n", ++(*pp), **pp); 
    printf("e) ++**pp = %d\n", ++(**pp));          

    printf("Updated array: ");
    for(int i=0; i<5; i++) {
        printf("%d ", a[i]);
    }

    printf("\n(Yatharth Chaudhary)");
    return 0;
}
    
