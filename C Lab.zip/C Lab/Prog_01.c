// Date:12/08/25

// WAP to understand the format specifiers(%c,%s,%d,%f,%o,%x,%6d,%6f,%6.2f,%.2f) for reading different types of variables.

#include<stdio.h>

int main()
{
   int a=45;
   char b='f';
   char l[]="My name is Yatharth Chaudhary";
   float c=4.56;
   int d=015;
   int k=15;
   printf("Integer value: %d\n", a);
   printf("character value: %c\n", b);
   printf("String: %s\n", l);
   printf("Float value: %f\n", c);
   printf("Octal  value: %o\n", d);
   printf("Hexadecimal  value: %d\n", a);
   printf("Intezer value with 6 digit precision: %6d\n", a);
   printf("Float value with 6 digit: %6f\n", c);
   


   return 0;
}