

// WAP for character input and output(use getchar() and putchar())

#include<stdio.h>

int main()
{
   
    int ch;
    printf("Enter the character: ");
    ch=getchar();
    printf("You entered: ");
    putchar(ch);
    return 0;
}