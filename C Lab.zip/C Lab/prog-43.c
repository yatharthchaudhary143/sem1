// 43. Write a program to count the number of lines in a file.

#include <stdio.h>

int main() {
    FILE *fp;
    char filename[100];
    char ch;
    int lineCount = 0;

    printf("Enter file name: ");
    scanf("%s", filename);

    fp = fopen(filename, "r");

    if (fp == NULL) {
        printf("Cannot open file!\n");
        return 0;
    }

    // Read each character until end of file
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == '\n') {
            lineCount++;
        }
    }

    // If file is not empty, count last line
    lineCount++;

    fclose(fp);

    printf("Total lines = %d\n", lineCount);

    return 0;
}
