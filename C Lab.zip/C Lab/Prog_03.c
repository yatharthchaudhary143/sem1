

// WAP to read from keyboard and display
//  *integer
// *real value
// *character
// *string
// *double(large real value)
// *unsigned value of integer
// *octal value of an intezer

#include <stdio.h>

int main()
{
  int a, o;
  float b;
  char ch, str[20];
  double d;
  unsigned int e;

  printf("Enter any integer: ");
  scanf("%d", &a);
  printf("You entered: %d\n", a);

  printf("\nEnter any real value: ");
  scanf("%f", &b);
  printf("You entered %f\n", b);

  printf("\nEnter any character: ");
  scanf(" %c", &ch);
  printf("You entered %c ", ch);
  printf("\n");

  printf("\nEnter string: ");
  scanf("%s", str);
  printf("You have entered '%s '\n ", str);

  printf("\nEnter double: ");
  scanf("%lf", &d);
  printf("You have entered %lf\n ", d);

  printf("\nEnter an unsigned integer: ");
  scanf("%u", &e);
  printf("You have entered %u\n ", e);

  printf("\nEnter octal: ");
  scanf("%d", &o);
  printf("You have entered %o\n ", o);

  return 0;
}