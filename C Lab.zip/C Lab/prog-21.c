//  WAP to generate the Fibonacci Series.

#include <stdio.h>

int Fib(int x){
        if (x<=1){
            return x;
        }
        return Fib(x-1)+Fib(x-2);
    }

int main(){

    int n;
    printf("\nEnter number of terms: ");
    scanf("%d",&n);
    printf("Fibonacci Series: ");
    for (int i=0; i<n; i++){
        printf("%d ",Fib(i));
    }
    printf("\n(Yatharth Chaudhary)");

    return 0;
}