// 49. Write a program to check whether a given number is even or odd in a given range using recursions.  

#include <stdio.h>

void checkEvenOdd(int start, int end) {
    if (start > end)
        return;

    if (start % 2 == 0)
        printf("%d is Even\n", start);
    else
        printf("%d is Odd\n", start);

    checkEvenOdd(start + 1, end);
}

int main() {
    int a, b;

    printf("Enter start of range: ");
    scanf("%d", &a);

    printf("Enter end of range: ");
    scanf("%d", &b);

    printf("\nChecking numbers from %d to %d:\n", a, b);

    checkEvenOdd(a, b);
    
    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}
