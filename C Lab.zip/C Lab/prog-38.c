// WAP to convert a number into string and a string into a number

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int num;
    char str[200];

    printf("Enter a number: ");
    scanf("%d", &num);

    itoa(num, str, 10);
    printf("\nNumber to String: %s", str);
    
    if (sizeof(str) > sizeof(num))
        printf("\nType after conversion: string\n");
    else
        printf("\nType after conversion: unknown\n");


    
    printf("\nEnter a numeric string: ");
    scanf("%s", str);

    num = atoi(str);

    printf("\nString to Number: %d", num);
    if (sizeof(num) == 4)
        printf("\nType after conversion: integer\n");
    else
        printf("\nType after conversion: unknown\n");


    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}

