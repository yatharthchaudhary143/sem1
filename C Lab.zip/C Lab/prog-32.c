// 32. Write a program that determines the use of string function. 
#include <stdio.h> 
#include <string.h> 
int main() { 
char str1[100], str2[100]; 
printf("Enter a string: "); 
gets(str1); 
printf("Length of string: %lu\n", strlen(str1)); 
strcpy(str2, str1); 
printf("Copied string: %s\n", str2); 
strcat(str1, " World"); 
printf("Concatenated string: %s\n", str1); 
printf("Comparing str1 and str2: %d\n", strcmp(str1, str2)); 
return 0; 
}