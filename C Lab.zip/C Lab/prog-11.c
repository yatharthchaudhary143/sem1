// WAP to make a simple calculator using switch statement

#include <stdio.h>

int main(){

    float a,b;
    char c;
    float res;

    printf("\nEnter 1st Number: ");
    scanf("%f",&a);
    printf("Enter 2nd Number: ");
    scanf("%f", &b);
    printf("Enter the operation (+,-,x,/): ");
    scanf(" %c",&c);

    switch (c)
    {
    case '+':
        res=a+b;
        break;

    case '-':
        res=a-b;
        break;

    case 'x':
        res=a*b;
        break;

    case '/':
        res=a/(b*1.0);
        break;

    default:
        break;
    }
    
    printf("Result: %.2f%c%.2f=%.2f\n", a,c,b,res);
    printf("\n(Yatharth Chaudhary)\n");

    return 0;
}