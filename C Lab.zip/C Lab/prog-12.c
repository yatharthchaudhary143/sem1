// WAP to calculate the sum of first n natural numbers

#include <stdio.h>

int main(){

    int n;
    int sum=0;
    printf("\nEnter the Number: ");
    scanf("%d",&n);

    for (int i=1; i<=n; i++){
        sum+=i;
    }

    printf("Sum of %d Natural Numbers: %d",n,sum);
    printf("\n(Yatharth Chaudhary)\n");

    return 0;
}