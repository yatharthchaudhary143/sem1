//WAP for maddition of two matrices of any order.

#include <stdio.h>


void enterMatrix(int r, int c, int M[r][c]){
    printf("\n");
    for (int i=0; i<r; i++){
        for (int j=0; j<c; j++){
            printf("Enter Element %d%d: ", i+1,j+1);
            scanf("%d", &M[i][j]);
        }
    }
}

void printMatrix(int r, int c, int M[r][c]){
    for (int i=0; i<r; i++){
        for (int j=0; j<c; j++){
            printf("%d ", M[i][j]);
        }
        printf("\n");
    }
}

void sumMatrix(int r,int c,int M1[r][c],int M2[r][c]){
    int S[r][c];
    for (int i=0; i<r; i++){
        for (int j=0; j<c; j++){
           S[i][j]=M1[i][j]+M2[i][j];
        }
    }
    printf("Sum of Matrices: ");
    printf("\n");
    printMatrix(r,c,S);
}

int main(){
    
    int r, c;

    printf("Enter number of Rows: ");
    scanf("%d", &r);
    printf("Enter number of Columns: ");
    scanf("%d", &c);
    
    int A[r][c];
    printf("Enter elements of Matrix-A: ");
    enterMatrix(r,c,A);
    printMatrix(r,c,A);

    int B[r][c];
    printf("Enter elements of Matrix-B: ");
    enterMatrix(r,c,B);
    printMatrix(r,c,B);

    sumMatrix(r,c,A,B);

    
    return 0;
}