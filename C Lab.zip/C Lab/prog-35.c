// Write a program to reverse the string without using strev() function

#include <stdio.h>
#include <string.h>

/*
int main(){

        char str[200];
        printf("Enter String: ");
        scanf("%s", str);
        
        int n=strlen(str);

        char rev[200];

        for (int i=n-1; i>=0; i-- ){
            rev[n-i-1]=str[i];
        }

        for (int i=0; i<n; i++ ){
            str[i]=rev[i];
        }

        printf("Reversed String is: %s", str);

    return 0;
}
    */

void revStr(char *l, char *r){
    while (l<r){
        char temp=*l;
        *l=*r;
        *r=temp;
        l++;
        r--;
    }
}

int main(){

    char str[200];
    printf("Enter String: ");
    scanf("%s", str);
        
    int n=strlen(str);

    revStr(str,str+n-1);
    printf("Reversed String is: %s", str);
    

    printf("\n(Yatharth Chaudhary)");


    return 0;
}