// WAP to reverse the array element

#include <stdio.h>

void printArray(int arr[], int size){
    for (int i=0; i<size; i++)
        printf("%d ", arr[i]);
}

void revArray(int *arr, int *l, int *r){
    while (l<r){
        int temp=*l;
        *l=*r;
        *r=temp;
        l++;
        r--;
    }
}

int main(){

    int arr[5]={3,7,4,2,9};
    int size=sizeof(arr)/sizeof(arr[0]);

    printf("\nOriginal Array: ");
    printArray(arr, size);
    
    printf("\nReversed Array: ");
    revArray(arr,arr,arr+size-1);
    printArray(arr,size);

    printf("\n(Yatharth Chaudhary)");

    return 0;
}