// 36. WAP to copy one string into another using pointers. 

#include <stdio.h> 
 
int main() { 
    char str1[100], str2[100]; 
    char *src = str1, *dest = str2; 
 
    printf("Enter a string: "); 
    gets(str1); 
 
    while (*src) { 
        *dest = *src; 
        src++; 
        dest++; 
    } 
    *dest = '\0'; 
 
    printf("Copied string: %s\n", str2); 
 
    return 0; 
} 
