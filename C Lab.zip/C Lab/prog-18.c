// WAP tp check whether a given number is Amstrong or not.

#include <stdio.h>
#include <math.h>

int main(){

    int n;
    printf("\nEnter any integer: ");
    scanf("%d",&n);

    int count=0;
    int org=n;

    while (n>=1){
        count++;
        n/=10;
    }

    int arm=0;
    int last;
    n=org;
    
    while (n>0){
        last=n%10;
        n/=10;
        arm=arm+pow(last,count);
    }

    if (arm==org){
        printf("%d is an Armstrong number\n", org);
    } 
    else {
        printf("%d is not an Armstrong number\n", org);
    }
    
    printf("(Yatharth Chaudhary)");
    return 0;
}