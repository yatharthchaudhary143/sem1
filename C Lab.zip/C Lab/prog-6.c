#include <stdio.h>

int main(){

    int a=10;
    float b=5.5;
    char c='A';

    printf("\nImplicit Conversion;\n");

    float res1=a+b;
    int res2=a+c;
    float res3=b-c;

    printf("a(int)+b(float): %.2f\n", res1);
    printf("a(int)+c(char): %d\n", res2);
    printf("b(float)-c(char): %.2f\n", res3);

    printf("\nExplicit Conversion;\n");

    int res4=(int)b+a;
    float res5=(float)a+b;
    char res6=(char)(a)+c;

    printf("(int)b+a: %d\n", res4);
    printf("(float)a+b: %.2f\n", res5);
    printf("(char)(a)+c: %c\n", res6);
    printf("\n");


    return 0;
}