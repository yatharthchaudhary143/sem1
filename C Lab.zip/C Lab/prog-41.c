// 41. Write a program that defines a structure "complex" (typedef) to read two complex numbers and perform addition, subtraction of these two complex numbers and display the result.

#include <stdio.h>

typedef struct {
    float real;
    float imag;
} complex;

complex add(complex c1, complex c2) {
    complex result;
    result.real = c1.real + c2.real;
    result.imag = c1.imag + c2.imag;
    return result;
}

complex subtract(complex c1, complex c2) {
    complex result;
    result.real = c1.real - c2.real;
    result.imag = c1.imag - c2.imag;
    return result;
}

int main() {
    complex c1, c2, sum, diff;

    printf("Enter first complex number (real imaginary): ");
    scanf("%f %f", &c1.real, &c1.imag);

    printf("Enter second complex number (real imaginary): ");
    scanf("%f %f", &c2.real, &c2.imag);

    sum = add(c1, c2);
    diff = subtract(c1, c2);

    printf("\nAddition = %.2f + %.2fi\n", sum.real, sum.imag);
    printf("Subtraction = %.2f + %.2fi\n", diff.real, diff.imag);

    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}
