// WAP to read a string and check for palindrome without using string related function 

#include <stdio.h>

int main(){

    char str[200];
    printf("\nEnter String: ");
    scanf("%s", str);

    int l=0, r, length=0, isPalindrome=1;

    while (str[length]!='\0'){
        length++;
    }

    r=length-1;
    while(l<r){
        if (str[l]!=str[r]){
            isPalindrome=0;
            break;
        }
        l++;
        r--;
    }

    if (isPalindrome){
        printf("The string is a palindrome");
    }
    else {
        printf("The string is NOT a palindrome");
    }

    printf("\n(Yatharth Chaudhary)");
    return 0;
}

