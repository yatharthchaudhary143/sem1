// WAP to read input until the user enters a positive integer

#include <stdio.h>

int main(){

    int n;
    do {
        printf("\nEnter any Number: ");
        scanf("%d",&n);
    } while (n<0);

    printf("You entered a positive number: %d\n", n);
    printf("\n(Yatharth Chaudhary)\n");
    return 0;
}